<?php

namespace Tests\Feature;

use App\Modules\Auth\Models\User;
use App\Modules\Auth\Services\PermissionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Tests\TestCase;

class AuthSecurityTest extends TestCase
{
    use RefreshDatabase;

    protected function authUrl(string $path): string
    {
        return '/api/v1/auth/' . ltrim($path, '/');
    }

    public function test_otp_cooldown_prevents_rapid_requests(): void
    {
        $mobile = '09121111111';

        // درخواست اول باید موفق باشد
        $first = $this->postJson($this->authUrl('login'), ['mobile' => $mobile]);
        $first->assertStatus(200);

        // درخواست دوم بلافاصله باید به خاطر cooldown رد شود (422)
        $second = $this->postJson($this->authUrl('login'), ['mobile' => $mobile]);
        $second->assertStatus(422);
        $second->assertJsonValidationErrors(['mobile']);
    }

    public function test_login_rate_limit_returns_429_after_too_many_requests(): void
    {
        $mobile = '09122222222';

        // فقط cooldown پاک می‌شود، نه شمارنده RateLimiter
        $clearCooldown = function () use ($mobile) {
            Cache::forget('otp_cooldown:' . $mobile);
            Cache::forget('otp_cooldown:' . $mobile . ':expires_at');
        };

        for ($i = 0; $i < 5; $i++) {
            $clearCooldown();
            $this->postJson($this->authUrl('login'), ['mobile' => $mobile]);
        }

        $clearCooldown();
        $blocked = $this->postJson($this->authUrl('login'), ['mobile' => $mobile]);

        // درخواست ششم باید توسط limiter با 429 رد شود
        $blocked->assertStatus(429);
    }

    public function test_verify_rate_limit_returns_429_after_too_many_attempts(): void
    {
        $mobile = '09123333333';

        // limiter ‏auth-verify: ۱۰ تلاش در دقیقه به ازای IP + mobile
        for ($i = 0; $i < 10; $i++) {
            $response = $this->postJson($this->authUrl('verify'), [
                'mobile' => $mobile,
                'code'   => '00000',
            ]);

            $this->assertNotEquals(
                429,
                $response->getStatusCode(),
                'تلاش شماره ' . ($i + 1) . ' نباید 429 بگیرد'
            );
        }

        $this->postJson($this->authUrl('verify'), [
            'mobile' => $mobile,
            'code'   => '00000',
        ])->assertStatus(429);
    }

    public function test_permission_service_returns_false_for_user_without_roles(): void
    {
        $user = User::create([
            'id'           => (string) Str::uuid(),
            'mobile_e164'  => '+989123333333',
            'display_name' => 'بدون نقش',
            'status'       => 'active',
        ]);

        $service = app(PermissionService::class);

        $this->assertFalse($service->userHasPermission($user, 'user.invite'));
        $this->assertFalse($service->isPlatformAdmin($user));
        $this->assertSame([], $service->getUserRoleCodes($user));
        $this->assertSame([], $service->getUserPermissionCodes($user));
    }

    public function test_permission_service_can_be_resolved_from_container(): void
    {
        $service = app(PermissionService::class);
        $this->assertInstanceOf(PermissionService::class, $service);
    }

    public function test_ip_rate_limit_blocks_after_20_requests_with_different_mobiles(): void
    {
        for ($i = 1; $i <= 20; $i++) {
            $mobile = '09120000' . str_pad((string) $i, 3, '0', STR_PAD_LEFT);

            $response = $this->postJson($this->authUrl('login'), [
                'mobile' => $mobile,
            ]);

            $this->assertNotEquals(
                429,
                $response->getStatusCode(),
                "درخواست شماره {$i} نباید 429 بگیرد"
            );
        }

        $blocked = $this->postJson($this->authUrl('login'), [
            'mobile' => '09120000999',
        ]);

        $blocked->assertStatus(429);
    }
}