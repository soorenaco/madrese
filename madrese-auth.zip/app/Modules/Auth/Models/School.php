<?php

namespace App\Modules\Auth\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class School extends Model
{
    use HasUuids;

    protected $fillable = [
        'name',
        'code',
        'city',
        'address',
        'status',
    ];

    public function classes(): HasMany
    {
        return $this->hasMany(SchoolClass::class, 'school_id');
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(SchoolMembership::class, 'school_id');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}