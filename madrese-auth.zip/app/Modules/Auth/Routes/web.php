<?php

use App\Modules\Auth\Controllers\Web\AuthController;
use App\Modules\Auth\Controllers\Web\ClassPromoteController;
use App\Modules\Auth\Controllers\Web\ClassRosterController;
use App\Modules\Auth\Controllers\Web\ClassScheduleController;
use App\Modules\Auth\Controllers\Web\SchoolClassController;
use App\Modules\Auth\Controllers\Web\SchoolController;
use App\Modules\Auth\Controllers\Web\SchoolDeputyController;
use App\Modules\Auth\Controllers\Web\UserManageController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('auth.login'));

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('auth.login');

    Route::post('/login', [AuthController::class, 'requestOtp'])
        ->middleware(['throttle:auth-login-ip', 'throttle:auth-login'])
        ->name('auth.login.request');

    Route::post('/login/verify', [AuthController::class, 'verifyOtp'])
        ->middleware('throttle:auth-verify')
        ->name('auth.login.verify');
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('auth.dashboard');
    Route::post('/logout', [AuthController::class, 'logout'])->name('auth.logout');

    Route::middleware('role:teacher,school_manager,admin')->group(function () {
        Route::get('/classes', [SchoolClassController::class, 'index'])->name('panel.classes');
        Route::get('/classes/create', [SchoolClassController::class, 'create'])->name('panel.classes.create');
        Route::post('/classes', [SchoolClassController::class, 'store'])->name('panel.classes.store');
        Route::get('/classes/{school_class}/edit', [SchoolClassController::class, 'edit'])->name('panel.classes.edit');
        Route::put('/classes/{school_class}', [SchoolClassController::class, 'update'])->name('panel.classes.update');
        Route::delete('/classes/{school_class}', [SchoolClassController::class, 'destroy'])->name('panel.classes.destroy');
    });

    Route::middleware('role:school_manager,admin')->group(function () {
        // اعضا
        Route::get('/classes/{school_class}/roster', [ClassRosterController::class, 'show'])->name('panel.classes.roster');
        Route::post('/classes/{school_class}/students', [ClassRosterController::class, 'inviteStudent'])->name('panel.classes.students.invite');
        Route::delete('/classes/{school_class}/students/{user}', [ClassRosterController::class, 'removeStudent'])->name('panel.classes.students.remove');
        Route::post('/classes/{school_class}/students/{user}/restore', [ClassRosterController::class, 'restoreStudent'])->name('panel.classes.students.restore');
        Route::put('/classes/{school_class}/students/{user}/status', [ClassRosterController::class, 'updateStudentStatus'])->name('panel.classes.students.status');
        Route::post('/classes/{school_class}/teacher', [ClassRosterController::class, 'assignTeacher'])->name('panel.classes.teacher');

        // M4 ارتقا
        Route::get('/classes/{school_class}/promote', [ClassPromoteController::class, 'show'])->name('panel.classes.promote');
        Route::post('/classes/{school_class}/promote', [ClassPromoteController::class, 'store'])->name('panel.classes.promote.store');

        // M5 برنامه
        Route::get('/classes/{school_class}/schedule', [ClassScheduleController::class, 'show'])->name('panel.classes.schedule');
        Route::post('/classes/{school_class}/schedule', [ClassScheduleController::class, 'store'])->name('panel.classes.schedule.store');

        // مدرسه
        Route::get('/school', [SchoolController::class, 'index'])->name('panel.school');
        Route::get('/school/create', [SchoolController::class, 'create'])->name('panel.school.create');
        Route::post('/school', [SchoolController::class, 'store'])->name('panel.school.store');
        Route::get('/school/{school}/edit', [SchoolController::class, 'edit'])->name('panel.school.edit');
        Route::put('/school/{school}', [SchoolController::class, 'update'])->name('panel.school.update');
        Route::delete('/school/{school}', [SchoolController::class, 'destroy'])->name('panel.school.destroy');

        // M6 معاونان
        Route::get('/school/{school}/deputies', [SchoolDeputyController::class, 'show'])->name('panel.school.deputies');
        Route::post('/school/{school}/primary-manager', [SchoolDeputyController::class, 'setPrimary'])->name('panel.school.primary');
        Route::post('/school/{school}/deputy-limits', [SchoolDeputyController::class, 'setLimits'])->name('panel.school.deputy-limits');

        Route::get('/users', [UserManageController::class, 'index'])->name('panel.users');
        Route::put('/users/{user}/status', [UserManageController::class, 'updateStatus'])->name('panel.users.status');
        Route::post('/users/{user}/membership', [UserManageController::class, 'assignMembership'])->name('panel.users.membership');
    });

    Route::get('/settings', fn () => \Inertia\Inertia::render('Settings/Index'))
        ->middleware('role:admin')
        ->name('panel.settings');
});
