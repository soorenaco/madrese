<?php

namespace App\Modules\Auth\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // ==========================================
            // مجوزهای سطح پلتفرم (مخصوص Admin)
            // ==========================================
            [
                'code'        => 'platform.manage',
                'resource'    => 'platform',
                'action'      => 'manage',
                'description' => 'مدیریت کامل پلتفرم',
            ],
            [
                'code'        => 'school.create',
                'resource'    => 'school',
                'action'      => 'create',
                'description' => 'ایجاد مدرسه جدید در سیستم',
            ],
            [
                'code'        => 'school.view_all',
                'resource'    => 'school',
                'action'      => 'view_all',
                'description' => 'مشاهده تمام مدارس پلتفرم',
            ],
            [
                'code'        => 'school.manage',
                'resource'    => 'school',
                'action'      => 'manage',
                'description' => 'ویرایش و مدیریت اطلاعات مدارس',
            ],
            [
                'code'        => 'user.manage_all',
                'resource'    => 'user',
                'action'      => 'manage_all',
                'description' => 'مدیریت تمام کاربران سیستم',
            ],
            [
                'code'        => 'role.manage_system',
                'resource'    => 'role',
                'action'      => 'manage_system',
                'description' => 'مدیریت نقش‌های سیستمی',
            ],
            [
                'code'        => 'permission.manage',
                'resource'    => 'permission',
                'action'      => 'manage',
                'description' => 'مدیریت مجوزها و دسترسی‌ها',
            ],
            [
                'code'        => 'system.settings',
                'resource'    => 'system',
                'action'      => 'settings',
                'description' => 'دسترسی به تنظیمات کلی سیستم',
            ],
            [
                'code'        => 'audit.view',
                'resource'    => 'audit',
                'action'      => 'view',
                'description' => 'مشاهده لاگ‌ها و گزارش‌های امنیتی',
            ],

            // ==========================================
            // مدیریت کاربران و عضویت (سطح مدرسه)
            // ==========================================
            [
                'code'        => 'user.invite',
                'resource'    => 'user',
                'action'      => 'invite',
                'description' => 'دعوت کاربر جدید به مدرسه',
            ],
            [
                'code'        => 'user.view',
                'resource'    => 'user',
                'action'      => 'view',
                'description' => 'مشاهده اطلاعات کاربران مدرسه',
            ],
            [
                'code'        => 'user.suspend',
                'resource'    => 'user',
                'action'      => 'suspend',
                'description' => 'تعلیق عضویت کاربر',
            ],

            // ==========================================
            // مدیریت نقش‌ها (سطح مدرسه)
            // ==========================================
            [
                'code'        => 'role.assign',
                'resource'    => 'role',
                'action'      => 'assign',
                'description' => 'اعطا یا لغو نقش به عضویت',
            ],
            [
                'code'        => 'role.view',
                'resource'    => 'role',
                'action'      => 'view',
                'description' => 'مشاهده نقش‌ها و مجوزها',
            ],

            // ==========================================
            // کلاس و ثبت‌نام
            // ==========================================
            [
                'code'        => 'class.manage',
                'resource'    => 'class',
                'action'      => 'manage',
                'description' => 'ایجاد و مدیریت کلاس‌ها',
            ],
            [
                'code'        => 'class.view',
                'resource'    => 'class',
                'action'      => 'view',
                'description' => 'مشاهده کلاس‌ها',
            ],

            // ==========================================
            // حضور و غیاب
            // ==========================================
            [
                'code'        => 'attendance.record',
                'resource'    => 'attendance',
                'action'      => 'record',
                'description' => 'ثبت حضور و غیاب',
            ],
            [
                'code'        => 'attendance.view',
                'resource'    => 'attendance',
                'action'      => 'view',
                'description' => 'مشاهده وضعیت حضور',
            ],

            // ==========================================
            // تکالیف
            // ==========================================
            [
                'code'        => 'assignment.manage',
                'resource'    => 'assignment',
                'action'      => 'manage',
                'description' => 'ایجاد و مدیریت تکالیف',
            ],
            [
                'code'        => 'assignment.view',
                'resource'    => 'assignment',
                'action'      => 'view',
                'description' => 'مشاهده تکالیف',
            ],
            [
                'code'        => 'assignment.submit',
                'resource'    => 'assignment',
                'action'      => 'submit',
                'description' => 'تحویل تکلیف توسط دانش‌آموز',
            ],

            // ==========================================
            // ارزیابی
            // ==========================================
            [
                'code'        => 'evaluation.manage',
                'resource'    => 'evaluation',
                'action'      => 'manage',
                'description' => 'ثبت و انتشار نتیجه',
            ],
            [
                'code'        => 'evaluation.view',
                'resource'    => 'evaluation',
                'action'      => 'view',
                'description' => 'مشاهده نتایج منتشرشده',
            ],
        ];

        foreach ($permissions as $permission) {
            $existing = DB::table('permissions')->where('code', $permission['code'])->first();

            if ($existing) {
                DB::table('permissions')
                    ->where('code', $permission['code'])
                    ->update([
                        'resource'    => $permission['resource'],
                        'action'      => $permission['action'],
                        'description' => $permission['description'],
                        'updated_at'  => now(),
                    ]);
            } else {
                DB::table('permissions')->insert([
                    'id'          => (string) Str::uuid(),
                    'code'        => $permission['code'],
                    'resource'    => $permission['resource'],
                    'action'      => $permission['action'],
                    'description' => $permission['description'],
                    'created_at'  => now(),
                    'updated_at'  => now(),
                ]);
            }
        }
    }
}
