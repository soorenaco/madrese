<?php

namespace App\Modules\Auth\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            // ==========================================
            // نقش سطح پلتفرم (بالاترین سطح)
            // ==========================================
            [
                'code'      => 'admin',
                'title'     => 'ادمین سیستم',
                'scope'     => 'platform',
                'is_system' => true,
            ],

            // ==========================================
            // نقش‌های سطح مدرسه و کلاس
            // ==========================================
            [
                'code'      => 'school_manager',
                'title'     => 'مدیر مدرسه',
                'scope'     => 'school',
                'is_system' => true,
            ],
            [
                'code'      => 'teacher',
                'title'     => 'معلم',
                'scope'     => 'class',
                'is_system' => true,
            ],
            [
                'code'      => 'counselor',
                'title'     => 'مشاور',
                'scope'     => 'assigned_students',
                'is_system' => true,
            ],

            // ==========================================
            // نقش‌های سطح کاربر / خانواده
            // ==========================================
            [
                'code'      => 'student',
                'title'     => 'دانش‌آموز',
                'scope'     => 'self',
                'is_system' => true,
            ],
            [
                'code'      => 'parent',
                'title'     => 'والدین',
                'scope'     => 'linked_child',
                'is_system' => true,
            ],

            // ==========================================
            // نقش کسب‌وکار / بازار
            // ==========================================
            [
                'code'      => 'bazaar',
                'title'     => 'بازار',
                'scope'     => 'assigned_students',
                'is_system' => true,
            ],

            // ==========================================
            // نقش راننده (برای هماهنگی با معماری اصلی پلتفرم)
            // ==========================================
            [
                'code'      => 'driver',
                'title'     => 'راننده',
                'scope'     => 'self',
                'is_system' => true,
            ],
        ];

        foreach ($roles as $role) {
            // اگر نقش از قبل وجود داشت، فقط title و scope را به‌روز می‌کنیم
            // و id را تغییر نمی‌دهیم تا روابط خراب نشود
            $existing = DB::table('roles')->where('code', $role['code'])->first();

            if ($existing) {
                DB::table('roles')
                    ->where('code', $role['code'])
                    ->update([
                        'title'      => $role['title'],
                        'scope'      => $role['scope'],
                        'is_system'  => $role['is_system'],
                        'updated_at' => now(),
                    ]);
            } else {
                DB::table('roles')->insert([
                    'id'         => (string) Str::uuid(),
                    'code'       => $role['code'],
                    'title'      => $role['title'],
                    'scope'      => $role['scope'],
                    'is_system'  => $role['is_system'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }
}
