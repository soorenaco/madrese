<?php

namespace App\Modules\Auth\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Modules\Auth\Models\School;
use App\Modules\Auth\Models\SchoolMembership;
use App\Modules\Auth\Models\User;
use App\Modules\Auth\Services\PermissionService;
use App\Modules\Auth\Services\SchoolManagerGate;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class SchoolDeputyController extends Controller
{
    public function __construct(
        protected PermissionService $permissions,
        protected SchoolManagerGate $gate
    ) {}

    public function show(Request $request, School $school): Response
    {
        $this->assertSchoolAccess($request, $school);

        $managers = SchoolMembership::query()
            ->where('school_id', $school->id)
            ->where('status', 'active')
            ->whereNull('ended_at')
            ->whereHas('roles', fn ($q) => $q->where('roles.code', 'school_manager'))
            ->with('user:id,display_name,mobile_e164')
            ->get()
            ->map(fn (SchoolMembership $m) => [
                'user_id'            => $m->user_id,
                'display_name'       => $m->user?->display_name,
                'mobile'             => $m->user?->mobile_e164,
                'is_primary_manager' => (bool) $m->is_primary_manager,
                'manager_limits'     => $m->manager_limits,
            ]);

        return Inertia::render('School/Deputies', [
            'school'   => $school->only(['id', 'name', 'code']),
            'managers' => $managers,
            'limitKeys' => SchoolManagerGate::LIMIT_KEYS,
            'canManage' => $this->gate->isPrimaryManager($request->user(), $school->id)
                || $this->permissions->isPlatformAdmin($request->user()),
        ]);
    }

    public function setPrimary(Request $request, School $school): RedirectResponse
    {
        $data = $request->validate([
            'user_id' => ['required', 'uuid', 'exists:users,id'],
        ]);

        $target = User::findOrFail($data['user_id']);
        $this->gate->setPrimaryManager($request->user(), $school->id, $target);

        return back()->with('success', 'مدیر اصلی مدرسه تنظیم شد.');
    }

    public function setLimits(Request $request, School $school): RedirectResponse
    {
        $data = $request->validate([
            'user_id' => ['required', 'uuid', 'exists:users,id'],
            'limits'  => ['required', 'array'],
        ]);

        $target = User::findOrFail($data['user_id']);
        $this->gate->setDeputyLimits($request->user(), $school->id, $target, $data['limits']);

        return back()->with('success', 'محدودیت معاون ذخیره شد.');
    }

    protected function assertSchoolAccess(Request $request, School $school): void
    {
        $user = $request->user();
        if ($this->permissions->isPlatformAdmin($user)) {
            return;
        }
        abort_unless($this->permissions->managesSchool($user, $school->id), 403);
    }
}
