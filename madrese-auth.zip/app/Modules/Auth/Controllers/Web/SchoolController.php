<?php

namespace App\Modules\Auth\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Modules\Auth\Models\School;
use App\Modules\Auth\Services\PermissionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class SchoolController extends Controller
{
    public function __construct(
        protected PermissionService $permissions
    ) {}

    public function index(Request $request): Response
    {
        $user = $request->user();
        $managedIds = $this->permissions->managedSchoolIds($user);

        $schools = School::query()
            ->withCount(['classes', 'memberships'])
            ->when($managedIds !== null, fn ($q) => $q->whereIn('id', $managedIds ?: ['00000000-0000-0000-0000-000000000000']))
            ->when($request->string('q')->toString(), function ($q, $term) {
                $q->where(function ($inner) use ($term) {
                    $inner->where('name', 'ilike', "%{$term}%")
                        ->orWhere('code', 'ilike', "%{$term}%")
                        ->orWhere('city', 'ilike', "%{$term}%");
                });
            })
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        return Inertia::render('School/Index', [
            'schools' => $schools,
            'filters' => [
                'q' => $request->string('q')->toString(),
            ],
            'canCreate' => $this->permissions->isPlatformAdmin($user),
            'canDelete' => $this->permissions->isPlatformAdmin($user),
        ]);
    }

    public function create(Request $request): Response
    {
        abort_unless($this->permissions->isPlatformAdmin($request->user()), 403);

        return Inertia::render('School/Form', [
            'school' => null,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        abort_unless($this->permissions->isPlatformAdmin($request->user()), 403);

        School::create($this->validated($request));

        return redirect()->route('panel.school')->with('success', 'مدرسه با موفقیت ایجاد شد.');
    }

    public function edit(Request $request, School $school): Response
    {
        abort_unless($this->permissions->managesSchool($request->user(), $school->id), 403);

        return Inertia::render('School/Form', [
            'school' => $school,
        ]);
    }

    public function update(Request $request, School $school): RedirectResponse
    {
        abort_unless($this->permissions->managesSchool($request->user(), $school->id), 403);

        $school->update($this->validated($request, $school->id));

        return redirect()->route('panel.school')->with('success', 'مدرسه به‌روزرسانی شد.');
    }

    public function destroy(Request $request, School $school): RedirectResponse
    {
        abort_unless($this->permissions->isPlatformAdmin($request->user()), 403);

        if ($school->classes()->exists() || $school->memberships()->exists()) {
            return redirect()->route('panel.school')->with('error', 'این مدرسه کلاس یا عضو دارد و قابل حذف نیست.');
        }

        $school->delete();

        return redirect()->route('panel.school')->with('success', 'مدرسه حذف شد.');
    }

    protected function validated(Request $request, ?string $ignoreId = null): array
    {
        return $request->validate([
            'name'    => ['required', 'string', 'max:200'],
            'code'    => ['nullable', 'string', 'max:40', Rule::unique('schools', 'code')->ignore($ignoreId)],
            'city'    => ['nullable', 'string', 'max:100'],
            'address' => ['nullable', 'string', 'max:500'],
            'status'  => ['required', Rule::in(['active', 'suspended'])],
        ], [
            'name.required' => 'نام مدرسه الزامی است.',
        ]);
    }
}
