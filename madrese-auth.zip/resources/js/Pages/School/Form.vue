<script setup>
import { Link, useForm } from '@inertiajs/vue3';
import PanelLayout from '../../Layouts/PanelLayout.vue';

const props = defineProps({
    school: { type: Object, default: null },
});

const isEdit = !!props.school;

const form = useForm({
    name: props.school?.name ?? '',
    code: props.school?.code ?? '',
    city: props.school?.city ?? '',
    address: props.school?.address ?? '',
    status: props.school?.status ?? 'active',
});

function submit() {
    if (isEdit) {
        form.put(`/school/${props.school.id}`);
    } else {
        form.post('/school');
    }
}
</script>

<template>
    <PanelLayout>
        <div class="max-w-xl">
            <div class="mb-6">
                <Link href="/school" class="text-sm text-violet-700 hover:underline">← بازگشت</Link>
                <h1 class="text-xl font-bold mt-2">{{ isEdit ? 'ویرایش مدرسه' : 'مدرسه جدید' }}</h1>
            </div>

            <form class="bg-white rounded-2xl border border-slate-200 p-5 space-y-4" @submit.prevent="submit">
                <div>
                    <label class="block text-sm text-slate-600 mb-1">نام مدرسه *</label>
                    <input v-model="form.name" type="text" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" />
                    <p v-if="form.errors.name" class="text-xs text-rose-600 mt-1">{{ form.errors.name }}</p>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm text-slate-600 mb-1">کد</label>
                        <input v-model="form.code" type="text" dir="ltr" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-mono" />
                        <p v-if="form.errors.code" class="text-xs text-rose-600 mt-1">{{ form.errors.code }}</p>
                    </div>
                    <div>
                        <label class="block text-sm text-slate-600 mb-1">شهر</label>
                        <input v-model="form.city" type="text" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" />
                    </div>
                </div>

                <div>
                    <label class="block text-sm text-slate-600 mb-1">آدرس</label>
                    <textarea v-model="form.address" rows="2" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" />
                </div>

                <div>
                    <label class="block text-sm text-slate-600 mb-1">وضعیت *</label>
                    <select v-model="form.status" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="active">فعال</option>
                        <option value="suspended">معلق</option>
                    </select>
                </div>

                <div class="flex gap-3 pt-2">
                    <button
                        type="submit"
                        class="px-4 py-2 rounded-xl bg-violet-700 text-white text-sm font-medium hover:bg-violet-800 disabled:opacity-50"
                        :disabled="form.processing"
                    >
                        {{ isEdit ? 'ذخیره تغییرات' : 'ایجاد مدرسه' }}
                    </button>
                    <Link href="/school" class="px-4 py-2 rounded-xl border border-slate-200 text-sm text-slate-600">انصراف</Link>
                </div>
            </form>
        </div>
    </PanelLayout>
</template>