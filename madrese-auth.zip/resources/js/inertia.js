import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';

// ورودی جدا از app.js تا با صفحه‌های Livewire (لاگین فعلی) تداخل نکند.
createInertiaApp({
    resolve: (name) => {
        const pages = import.meta.glob('./Pages/**/*.vue', { eager: true });
        return pages[`./Pages/${name}.vue`];
    },
    setup({ el, App, props, plugin }) {
        createApp({ render: () => h(App, props) })
            .use(plugin)
            .mount(el);
    },
});
