<?php

namespace App\Modules\Auth\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // مدیریت کاربران و عضویت
            ['code' => 'user.invite', 'resource' => 'user', 'action' => 'invite', 'description' => 'دعوت کاربر جدید به مدرسه'],
            ['code' => 'user.view', 'resource' => 'user', 'action' => 'view', 'description' => 'مشاهده اطلاعات کاربران مدرسه'],
            ['code' => 'user.suspend', 'resource' => 'user', 'action' => 'suspend', 'description' => 'تعلیق عضویت کاربر'],

            // مدیریت نقش‌ها
            ['code' => 'role.assign', 'resource' => 'role', 'action' => 'assign', 'description' => 'اعطا یا لغو نقش به عضویت'],
            ['code' => 'role.view', 'resource' => 'role', 'action' => 'view', 'description' => 'مشاهده نقش‌ها و مجوزها'],

            // کلاس و ثبت‌نام
            ['code' => 'class.manage', 'resource' => 'class', 'action' => 'manage', 'description' => 'ایجاد و مدیریت کلاس‌ها'],
            ['code' => 'class.view', 'resource' => 'class', 'action' => 'view', 'description' => 'مشاهده کلاس‌ها'],

            // حضور و غیاب
            ['code' => 'attendance.record', 'resource' => 'attendance', 'action' => 'record', 'description' => 'ثبت حضور و غیاب'],
            ['code' => 'attendance.view', 'resource' => 'attendance', 'action' => 'view', 'description' => 'مشاهده وضعیت حضور'],

            // تکالیف
            ['code' => 'assignment.manage', 'resource' => 'assignment', 'action' => 'manage', 'description' => 'ایجاد و مدیریت تکالیف'],
            ['code' => 'assignment.view', 'resource' => 'assignment', 'action' => 'view', 'description' => 'مشاهده تکالیف'],
            ['code' => 'assignment.submit', 'resource' => 'assignment', 'action' => 'submit', 'description' => 'تحویل تکلیف توسط دانش‌آموز'],

            // ارزیابی
            ['code' => 'evaluation.manage', 'resource' => 'evaluation', 'action' => 'manage', 'description' => 'ثبت و انتشار نتیجه'],
            ['code' => 'evaluation.view', 'resource' => 'evaluation', 'action' => 'view', 'description' => 'مشاهده نتایج منتشرشده'],
        ];

        foreach ($permissions as $permission) {
            DB::table('permissions')->updateOrInsert(
                ['code' => $permission['code']],
                [
                    'id' => Str::uuid(),
                    'resource' => $permission['resource'],
                    'action' => $permission['action'],
                    'description' => $permission['description'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}